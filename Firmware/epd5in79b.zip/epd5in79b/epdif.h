#ifndef EPDIF_H
#define EPDIF_H

#include <Arduino.h>

#define RST_PIN   5
#define DC_PIN    6
#define CS_PIN    7
#define BUSY_PIN  4
#define PWR_PIN   3

class EpdIf {
public:
    static int  IfInit(void);
    static void DigitalWrite(int pin, int value);
    static int  DigitalRead(int pin);
    static void DelayMs(unsigned int delaytime);
    static void SpiTransfer(unsigned char data);
};

#endif
