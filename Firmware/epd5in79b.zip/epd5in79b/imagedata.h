#ifndef _IMAGEDATA_H_
#define _IMAGEDATA_H_

// Empty on purpose.
// We are loading images from SPIFFS, not PROGMEM.

#endif
