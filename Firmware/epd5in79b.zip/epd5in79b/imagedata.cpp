// Empty on purpose.
// No PROGMEM images. Using SPIFFS instead.
